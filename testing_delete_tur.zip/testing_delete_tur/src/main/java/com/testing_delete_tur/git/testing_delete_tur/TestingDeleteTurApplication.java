package com.testing_delete_tur.git.testing_delete_tur;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingDeleteTurApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestingDeleteTurApplication.class, args);
	}

}
